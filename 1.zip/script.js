/* ===== ХУЙ ===== */
let flame=100, clickPower=3, flamePoints=0, eraScore=0, totalClicks=0, era=2;
const thresholds=[500,1000,2000,3000,5000];
const MAX_BUYS_PER_TYPE=5;

/* Decay model */
let baseDecrease=1, decreaseRate=1, decayReductionTotal=0;
let fireGuardianUsed=false; // resets each era when you have the upgrade

/* DOM */
const fireButton=document.getElementById("fireButton");
const flameLevel=document.getElementById("flameLevel");
const flameText=document.getElementById("flameText");
const message=document.getElementById("message");
const flamePointsDisplay=document.getElementById("flamePoints");
const clicksCount=document.getElementById("clicksCount");
const eraProgress=document.getElementById("eraProgress");
const eraGoalText=document.getElementById("eraGoalText");
const eraText=document.querySelector(".era");
const shopList=document.getElementById("shopList");
const shopTheme=document.getElementById("shopTheme");
const clickSound=document.getElementById("clickSound");
const upgradeSound=document.getElementById("upgradeSound");
const newEraSound=document.getElementById("newEraSound");

/* Assets */
const backgrounds=["1.png","2.png","3.png","4.png","5.png","6.png"];
const eraNames=["Prehistoric","Ancient","Medieval","Industrial","Modern","Future"];
const eraThemes=[
  "First steps, struggle for warmth.",
  "Sacred fire and tradition.",
  "Fire of knowledge, craft, and progress.",
  "Fire as energy, productive force.",
  "Technological and electrical fire.",
  "Fire as symbol of the Universe."
];
const fireEraClasses=["fire-era-1","fire-era-2","fire-era-3","fire-era-4","fire-era-5","fire-era-6"];

/* Persistent upgrades across eras */
const purchasedCounts={}; // {title: count}
let activeIntervals=[];   // intervals created by upgrades
let decayLoop=null;       // main decay loop

/* Helpers */
function setMessage(t,ms=2000){message.textContent=t;if(ms>0)setTimeout(()=>{if(message.textContent===t)message.textContent=""},ms);}
function spawnFloatingText(x,y,text="+1🔥"){const el=document.createElement("div");el.className="float-text";el.textContent=text;el.style.left=(x-8)+"px";el.style.top=(y-20)+"px";document.body.appendChild(el);setTimeout(()=>el.remove(),1000);}
function clampFlame(){if(flame>100)flame=100;if(flame<0)flame=0;}
function updateFlameUI(){
  clampFlame();
  flameLevel.style.width = flame + "%";
  flameText.textContent = `Flame: ${Math.floor(flame)}%`;

  // scale fire inner, but keep button same size
  const fireInner = document.getElementById("fireInner");
  if (fireInner) {
    const scale = 0.4 + 0.6 * (flame / 100); // min 0.4x, max 1.0x
    fireInner.style.transform = `translate(-50%, -50%) scale(${scale})`;
  }
}

function updatePointsUI(){flamePointsDisplay.textContent=flamePoints;clicksCount.textContent=totalClicks;}
function updateProgressUI(){const p=Math.min(eraScore/thresholds[era-1]*100,100);eraProgress.style.width=p+"%";eraGoalText.textContent=`Next Era Progress: ${Math.floor(p)}%`;}
function recomputeDecay(){decreaseRate=Math.max(0,baseDecrease-decayReductionTotal);}

/* Decay Loop */
function setEraBase(){baseDecrease=1+4.0*(era-1);recomputeDecay();}
function startDecay(){
  if(decayLoop)clearInterval(decayLoop);
  decayLoop=setInterval(()=>{
    flame-=decreaseRate;
    if(flame<=0){handleFlameOut();}
    updateFlameUI();
  },1000);
}

/* Fire Guardian Save */
function handleFlameOut(){
  const hasFG = (purchasedCounts["Fire Guardian"]||0)>0;
  if(hasFG && !fireGuardianUsed){
    fireGuardianUsed=true;
    flame=30; // revive
    fireButton.classList.add("fire-flare");
    setTimeout(()=>fireButton.classList.remove("fire-flare"),1000);
    setMessage("🔥 Fire Guardian saved you!",2000);
    alert("🔥 Fire Guardian saved you!");
    updateFlameUI();
    return;
  }
  gameOver();
}

/* Game Over */
function gameOver(){
  if(decayLoop)clearInterval(decayLoop);
  activeIntervals.forEach(id=>clearInterval(id));
  activeIntervals=[];
  fireButton.remove(); // fire is gone
  setMessage("💀 The fire is out. Civilization has fallen.",4000);
}

/* Upgrades (buffed a bit) */
const eraUpgrades={
  1:{icon:["🪶","🪨","🔥","🧍‍♂️"],title:["Dry Branches","Stone Circle","Flint & Tinder","Guardian Tribe"],desc:[
      "Increase click power (+1.2 per buy).",
      "Reduce extinguishing speed (−0.15 per buy).",
      "10% per buy chance every 5s to gain +1🔥.",
      "+1🔥 every 5s per buy."
    ],
    cost:[100,120,140,160],
    once:[false,false,false,false], // once-only flags
    apply:[
      ()=>{ clickPower+=1.2; },
      ()=>{ decayReductionTotal+=0.15; recomputeDecay(); },
      (title)=>{ const id=setInterval(()=>{
          if(Math.random() < 0.10*(purchasedCounts[title]||0)){
            flamePoints++; eraScore++; updatePointsUI(); updateProgressUI();
          }
        },5000); activeIntervals.push(id);
      },
      ()=>{ const id=setInterval(()=>{
          flamePoints++; eraScore++; updatePointsUI(); updateProgressUI();
        },5000); activeIntervals.push(id);
      }
    ]},
  2:{icon:["🏺","⚱️","🕊️","⚡"],title:["Torch Oil","Marble Hearth","Priest of Vesta","Torch of Olympus"],desc:[
      "Slower decay (−0.15 per buy).",
      "Stabilize flame (−0.25 per buy).",
      "+1🔥 every 6s per buy.",
      "Clicks stronger (+2.5 per buy)."
    ],
    cost:[200,240,260,300],
    once:[false,false,false,false],
    apply:[
      ()=>{ decayReductionTotal+=0.15; recomputeDecay(); },
      ()=>{ decayReductionTotal+=0.25; recomputeDecay(); },
      ()=>{ const id=setInterval(()=>{
          flamePoints++; eraScore++; updatePointsUI(); updateProgressUI();
        },6000); activeIntervals.push(id);
      },
      ()=>{ clickPower+=2.5; }
    ]},
  3:{icon:["🔩","📜","🕯️","🏰"],title:["Forge","Alchemist","Candle of Enlightenment","Fire Guardian"],desc:[
      "Clicks add +2.5🔥 per buy.",
      "Regenerate flame: +2🔥 per buy every 2s.",
      "Restore flame: +2🔥 per buy every 2s.",
      "One-time save from extinction each era (buy only once)."
    ],
    cost:[320,360,380,420],
    once:[false,false,false,true],  // Fire Guardian once-only
    apply:[
      ()=>{ clickPower+=2.5; },
      (title)=>{ const id=setInterval(()=>{
          const n=purchasedCounts[title]||0;
          if(n>0){ flame=Math.min(100,flame+2*n); updateFlameUI(); }
        },2000); activeIntervals.push(id);
      },
      (title)=>{ const id=setInterval(()=>{
          const n=purchasedCounts[title]||0;
          if(n>0){ flame=Math.min(100,flame+2*n); updateFlameUI(); }
        },2000); activeIntervals.push(id);
      },
      ()=>{ /* handled in handleFlameOut() when needed */ }
    ]},
  4:{icon:["⚙️","🔧","🧱","🧍‍♀️"],title:["Steam Blower","Metal Firebox","Factory Boiler","Work Shifts"],desc:[
      "Passive +3🔥 every 1.5s (per buy).",
      "Reduce decay (−0.18 per buy).",
      "+4🔥 every 3s (per buy).",
      "Every 20 clicks → +1 click power (persistent)."
    ],
    cost:[480,520,560,600],
    once:[false,false,false,false],
    apply:[
      (title)=>{ const id=setInterval(()=>{
          const n=purchasedCounts[title]||0;
          if(n>0){ flame=Math.min(100,flame+3*n); updateFlameUI(); }
        },1500); activeIntervals.push(id);
      },
      ()=>{ decayReductionTotal+=0.18; recomputeDecay(); },
      (title)=>{ const id=setInterval(()=>{
          const n=purchasedCounts[title]||0;
          if(n>0){ flame=Math.min(100,flame+4*n); updateFlameUI(); }
        },3000); activeIntervals.push(id);
      },
      ()=>{ /* handled in click logic */ }
    ]},
  5:{icon:["🔋","🌞","🖥️","🌃"],title:["Electric Heating","Solar Panel","Smart Control System","Neon Pulse"],desc:[
      "Reduce decay (−0.20 per buy).",
      "+5🔥 every 8s (per buy).",
      "Decay floor min 0.2.",
      "Visual neon pulse (buy only once)."
    ],
    cost:[700,740,760,800],
    once:[false,false,false,true], // Neon Pulse once-only
    apply:[
      ()=>{ decayReductionTotal+=0.20; recomputeDecay(); },
      (title)=>{ const id=setInterval(()=>{
          const n=purchasedCounts[title]||0;
          if(n>0){ flame=Math.min(100,flame+5*n); updateFlameUI(); }
        },8000); activeIntervals.push(id);
      },
      ()=>{ /* floor handled via recompute; set here if desired */
        // If you want a floor: uncomment next lines:
        // minDecayFloor = 0.2;
        // recomputeDecay();
      },
      ()=>{ document.body.classList.add("neon"); }
    ]},
  6:{icon:["💫","🧬","☀️","⚛️"],title:["Plasma Core","Mind Fire","Star Synthesizer","Quantum Flame"],desc:[
      "No decay (buy only once).",
      "+1🔥 per click (per buy).",
      "+10🔥 every 10s (per buy).",
      "Eternal glow (buy only once)."
    ],
    cost:[900,950,1100,1500],
    once:[true,false,false,true], // Plasma Core & Quantum Flame once-only
    apply:[
      ()=>{ decreaseRate=0; }, // hard override
      ()=>{ clickPower+=1; },
      (title)=>{ const id=setInterval(()=>{
          const n=purchasedCounts[title]||0;
          if(n>0){ flame=Math.min(100,flame+10*n); updateFlameUI(); }
        },10000); activeIntervals.push(id);
      },
      ()=>{ document.body.classList.add("neon"); }
    ]}
};

/* Shop (current era only) */
function renderShop(){
  shopList.innerHTML="";
  shopTheme.textContent=eraThemes[era-1];
  const data=eraUpgrades[era];

  data.title.forEach((t,i)=>{
    const wrap=document.createElement("div");wrap.className="upgrade";
    const icon=document.createElement("div");icon.className="upg-icon";icon.textContent=data.icon[i];
    const body=document.createElement("div");body.className="upg-body";
    const h4=document.createElement("h4");h4.className="upg-title";h4.textContent=t;
    const desc=document.createElement("p");desc.className="upg-desc";desc.textContent=data.desc[i];

    const bottom=document.createElement("div");bottom.className="upg-bottom";
    const meta=document.createElement("span");meta.className="upg-meta";
    const bought=purchasedCounts[t]||0;
    const onceOnly=data.once[i]===true;
    meta.textContent=`Cost: ${data.cost[i]} 🔥 • Bought: ${bought}/${onceOnly?1:MAX_BUYS_PER_TYPE}`;

    const btn=document.createElement("button");btn.className="upg-buy";btn.textContent="Buy";
    btn.disabled = (onceOnly ? bought>=1 : bought>=MAX_BUYS_PER_TYPE) || flamePoints < data.cost[i];

    btn.addEventListener("click",()=>tryBuyUpgrade(era,i,t,meta,btn));

    bottom.append(meta,btn); body.append(h4,desc,bottom);
    wrap.append(icon,body); shopList.appendChild(wrap);
  });
}

/* Buying */
function tryBuyUpgrade(e,i,title,metaEl,btn){
  const data=eraUpgrades[e];
  const cost=data.cost[i];
  const onceOnly=data.once[i]===true;
  const current=purchasedCounts[Math.trunc?title:title]||0; // guard

  const maxAllowed = onceOnly ? 1 : MAX_BUYS_PER_TYPE;
  if(current>=maxAllowed){ btn.disabled=true; setMessage("Maxed out!"); return; }
  if(flamePoints<cost){ setMessage("Not enough points!"); return; }

  flamePoints-=cost;
  purchasedCounts[title]=(purchasedCounts[title]||0)+1;
  updatePointsUI();

  // Apply effect
  const applier=data.apply[i];
  if(applier.length===1){ applier(title); } else { applier(); }

  upgradeSound.currentTime=0; upgradeSound.play();
  const n=purchasedCounts[title];
  metaEl.textContent=`Cost: ${cost} 🔥 • Bought: ${n}/${maxAllowed}`;
  if(n>=maxAllowed) btn.disabled=true;

  refreshShopAffordability();
}

/* Affordability refresh */
function refreshShopAffordability(){
  const data=eraUpgrades[era];
  const buttons=shopList.querySelectorAll(".upg-buy");
  buttons.forEach((btn,idx)=>{
    const t=data.title[idx];
    const onceOnly=data.once[idx]===true;
    const maxAllowed=onceOnly?1:MAX_BUYS_PER_TYPE;
    const count=purchasedCounts[t]||0;
    btn.disabled = count>=maxAllowed || flamePoints < data.cost[idx];
  });
}

/* Clicking the fire */
let workShiftBonus=0;
fireButton.addEventListener("click",(e)=>{
  // base point gain
  let gain=1;
  flame=Math.min(100,flame+clickPower);
  flamePoints+=gain; eraScore+=gain; totalClicks++;

  // Work Shifts: simple persistent boost every 20 clicks if bought
  const wsBuys=purchasedCounts["Work Shifts"]||0;
  const cap=3+wsBuys;
  if(wsBuys>0 && totalClicks%20===0 && workShiftBonus<cap){
    workShiftBonus++; clickPower+=1;
    setMessage(`🛠️ Work shift efficiency +1 (now +${workShiftBonus})`,1200);
  }

  updateFlameUI(); updatePointsUI(); updateProgressUI();
  clickSound.currentTime=0; clickSound.play();
  spawnFloatingText(e.clientX,e.clientY,`+${gain}🔥`);

  // Era advancement: need threshold AND maxed era upgrades
  if(eraScore>=thresholds[era-1]){
    if(allCurrentEraMaxed()){
      goNextEra();
    }else{
      setMessage("⚠️ You must max all upgrades of this era to unlock the next era.");
    }
  }

  refreshShopAffordability();
});

/* Era helpers */
function allCurrentEraMaxed(){
  const data=eraUpgrades[era];
  if(!data) return true;
  return data.title.every((t,i)=>{
    const onceOnly=data.once[i]===true;
    const need=onceOnly?1:MAX_BUYS_PER_TYPE;
    return (purchasedCounts[t]||0) >= need;
  });
}

function goNextEra(){
  if(era>=6){ setMessage("🏆 Final Era reached!"); return; }
  era++; eraScore=0; fireGuardianUsed=false; // new era, guardian can trigger once again if owned
  // Visuals
  document.body.style.background=`url(${backgrounds[era-1]}) center/cover no-repeat fixed`;
  fireButton.className="fire-button "+fireEraClasses[era-1];
  eraText.textContent=`Era: ${eraNames[era-1]}`;

  setEraBase(); startDecay();

  newEraSound.currentTime=0; newEraSound.play();
  setMessage(`✨ A new era begins: ${eraNames[era-1]}! ✨`,2500);

  renderShop();
  updateProgressUI();
  refreshShopAffordability();
}

/* Init */
function init(){
  eraText.textContent=`Era: ${eraNames[era-1]}`;
  document.body.style.background=`url(${backgrounds[era-1]}) center/cover no-repeat fixed`;
  fireButton.classList.add(fireEraClasses[era-1]);
  setEraBase(); startDecay(); renderShop();
  updateFlameUI(); updatePointsUI(); updateProgressUI(); refreshShopAffordability();
}
init();
